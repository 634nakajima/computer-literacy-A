import sys
import json
from docx import Document
from docx.shared import Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def set_font(run, font_name_ascii, font_name_eastasia, size_pt, bold=False):
    run.font.name = font_name_ascii
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name_eastasia)
    run.font.size = Pt(size_pt)
    run.font.bold = bold
    run.font.color.rgb = RGBColor(0, 0, 0)

def is_list(text):
    return any(text.startswith(prefix) for prefix in ['１．', '２．', '３．', '４．', '５．', '・', '-'])

def generate_report(data, output_path):
    doc = Document()
    
    # Set default line spacing to 1.15
    style = doc.styles['Normal']
    style.paragraph_format.line_spacing = 1.15
    style.paragraph_format.space_after = Pt(0)

    # 1. Date (Right aligned, 10.5pt)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run(data.get('date', ''))
    set_font(run, 'Century', 'MS Mincho', 10.5)

    # 2. Title (Center aligned, 16pt)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(12)
    p.paragraph_format.space_after = Pt(12)
    run = p.add_run(data.get('title', ''))
    set_font(run, 'Arial', 'MS Gothic', 16, bold=False)

    # 3. Affiliation (Right aligned, 10.5pt)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    run = p.add_run(data.get('affiliation', ''))
    set_font(run, 'Century', 'MS Mincho', 10.5)

    # 4. Name (Right aligned, 10.5pt)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    p.paragraph_format.space_after = Pt(18) # 氏名の下に間隔を追加
    run = p.add_run(data.get('name', ''))
    set_font(run, 'Century', 'MS Mincho', 10.5)

    # Content
    content = data.get('content', [])
    for i, item in enumerate(content):
        type = item.get('type')
        text = item.get('text', '')

        if type == 'h1': # Chapter Heading
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(12)
            p.paragraph_format.space_after = Pt(6)
            run = p.add_run(text)
            set_font(run, 'Arial', 'MS Gothic', 14, bold=False)
        
        elif type == 'h2': # Section Heading
            p = doc.add_paragraph()
            p.paragraph_format.space_before = Pt(8)
            p.paragraph_format.space_after = Pt(4)
            run = p.add_run(text)
            set_font(run, 'Arial', 'MS Gothic', 12, bold=False)
            
        elif type == 'p': # Paragraph
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY # 両端揃え
            
            # 箇条書きの判定
            current_is_list = is_list(text)
            
            if current_is_list:
                # 箇条書きブロックの開始判定
                prev_is_list = i > 0 and content[i-1].get('type') == 'p' and is_list(content[i-1].get('text', ''))
                if not prev_is_list:
                    p.paragraph_format.space_before = Pt(6)
                
                # 箇条書きブロックの終了判定
                next_is_list = i < len(content) - 1 and content[i+1].get('type') == 'p' and is_list(content[i+1].get('text', ''))
                if not next_is_list:
                    p.paragraph_format.space_after = Pt(6)
                
                display_text = text # 箇条書きは字下げしない
            else:
                # 通常の段落は全角1字下げ
                display_text = text if text.startswith('　') else '　' + text
            
            run = p.add_run(display_text)
            set_font(run, 'Century', 'MS Mincho', 10.5)
            
        elif type == 'caption': # Figure Caption
            p = doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(text)
            set_font(run, 'Century', 'MS Mincho', 10.5)

    doc.save(output_path)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage: python generate_report_docx.py <json_data_path> <output_docx_path>")
        sys.exit(1)
    
    with open(sys.argv[1], 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    generate_report(data, sys.argv[2])
